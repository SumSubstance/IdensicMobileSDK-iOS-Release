//
//  SNSLiveness3D.h
//  IdensicMobileSDK_Liveness3D
//
//  Copyright © 2019 Sum & Substance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <IdensicMobileSDK/SNSMobileSDK.h>
#import <IdensicMobileSDK/SNSLiveness3DTheme.h>

@class SNSLiveness3DResult;

/**
 * Module modes
 */
typedef NS_ENUM(NSInteger, SNSLiveness3DMode) {
    SNSLiveness3DMode_FaceLiveness,
    SNSLiveness3DMode_FaceAuth,
};

/**
 * Actions to use in `responseHandler`
 */
typedef NS_ENUM(NSInteger, SNSLiveness3DAction) {
    SNSLiveness3DAction_Continue,
    SNSLiveness3DAction_Cancel,
};

/**
 * Completion status
 */
typedef NS_CLOSED_ENUM(NSInteger, SNSLiveness3DCompletionStatus) {
    
    /// Process has been cancelled
    SNSLiveness3DCompletionStatus_Cancelled,
    
    /// Initialization has been failed
    SNSLiveness3DCompletionStatus_InitializationFailed,
    
    /// Camera permission denied
    SNSLiveness3DCompletionStatus_CameraPermissionDenied,
    
    /// Access token is invalid or has expired
    SNSLiveness3DCompletionStatus_TokenIsInvalid,
    
    /// There is no applicant for the access token provided
    SNSLiveness3DCompletionStatus_ApplicantNotFound,
    
    /// Face mismatch detected (see `shouldCompleteOnFaceMismatch`)
    SNSLiveness3DCompletionStatus_FaceMismatched,
    
    /// Verification has been passed successfully
    SNSLiveness3DCompletionStatus_VerificationPassedSuccessfully,
};

extern NSErrorDomain _Nonnull const SNSLiveness3DErrorDomain;

typedef NS_ERROR_ENUM(SNSLiveness3DErrorDomain, SNSLiveness3DError) {
    SNSLiveness3DError_None = noErr,
    SNSLiveness3DError_InvalidParameters = -1,
};

typedef void(^SNSLiveness3DCompletionHandler)(UIViewController * _Nonnull viewController,
                                              SNSLiveness3DCompletionStatus completionStatus,
                                              SNSLiveness3DResult * _Nullable result);
typedef void(^SNSLiveness3DResultHandler)(SNSLiveness3DResult * _Nonnull result,
                                          void(^_Nonnull onComplete)(SNSLiveness3DAction action));

#pragma mark -

@interface SNSLiveness3D : NSObject

+ (nonnull NSString *)descriptionForCompletionStatus:(SNSLiveness3DCompletionStatus)completionStatus;

/**
 * Prepares Module for the launch
 *
 * @param mode Defines the mode the module should work in
 * @param baseUrl Base url to the backend. Please, use full qualified url with `https://` prefix
 * @param accessToken An access token for the applicant to be verified
 * @param locale Use locale in a form of `en_US`
 *
 * @discussion
 * The module could be used in two mode:
 * - `.faceLiveness` - check the face liveness and update the applicant data accordingly
 * - `.faceAuth` - check the liveness then match the face against the exising applicant
 */
+ (nullable instancetype)setupWithWithMode:(SNSLiveness3DMode)mode
                                   baseUrl:(nonnull NSString *)baseUrl
                               accessToken:(nonnull NSString *)accessToken
                                    locale:(nullable NSString *)locale
                                     error:(NSError * _Nullable * _Nullable)error __attribute__((swift_error(nonnull_error)))

NS_SWIFT_NAME(init(mode:baseUrl:accessToken:locale:));

+ (nonnull instancetype)new NS_UNAVAILABLE;
- (nonnull instancetype)init NS_UNAVAILABLE;

#pragma mark - Handlers

/**
 * Sets token expiration handler
 *
 * @param handler A closure that takes another closure `onComplete` as the only parameter.
 *
 * @discussion
 * Token expiration handler fired when `accessToken` is expired.
 * MUST call `onComplete` with new `accessToken` as a parameter.
 */
- (void)tokenExpirationHandler:(nullable SNSTokenExpirationHandler)handler;

/**
 * Sets completion handler
 *
 * @param handler A closure that takes `viewController`, `completionStatus` and possible `result`
 *
 * @discussion
 * Completion handler is called when the processing reaches one of the final states described by `result.status`.
 * Use `result` to examine the last result got from the backend (if any).
 *
 * See also `resultHandler` if you'd like to get notified every time the new result is arrived from the backend.
 *
 * Pay attention please that if `completionHandler` is assigned, it's up to you to dismiss the `viewController`.
 */
- (void)completionHandler:(nullable SNSLiveness3DCompletionHandler)handler;

/**
 * Sets an optional handler to be called right after a new result is got from the backend.
 *
 * @param handler A closure that takes `result` and `onComplete` closure.
 *
 * @discussion
 * MUST call `onComplete` with desired action:
 * - pass `.continue` to proceed with default scenario
 * - or pass `.cancel` to force the processing to complete with `.cancelled` status.
 */
- (void)resultHandler:(nullable SNSLiveness3DResultHandler)handler;

#pragma mark - UI

/**
 * Main view controller of the module's user interface
 *
 * @discussion
 * Upon success setup get and present `viewController`
 */
@property (nonatomic, readonly, nonnull) UIViewController *viewController;

#pragma mark - Customization

/**
 * Customization Theme
 *
 * @discussion
 * One can pass own theme object of `SNSLiveness3DTheme` class or adjust the default one using writtable properties
 */
@property (nonatomic, nonnull) SNSLiveness3DTheme *theme;

/**
 * Name of the .strings file to get texts from.
 *
 * @discussion
 * By default Module looks for `Liveness3D.strings` file in the main bundle.
 * If you'd like to keep localizations in another .strings file, assign its name here (just the name, without .strings extension)
 */
@property (nonatomic, nonnull) NSString *localizationTableName;

/**
 * A flag to force the processing to be completed when face mismatch is detected
 *
 * @dicussion
 * The overall process is looped until cancelled or completes successfully.
 * So normally you never get `.faceMismatched` completion status.
 * Setting `shouldCompleteOnFaceMismatch` flag changes this behaviour.
 */
@property (nonatomic) bool shouldCompleteOnFaceMismatch;

#pragma mark - Logging

/**
 * Logging level (`Off` by default)
 */
@property (nonatomic) SNSLogLevel logLevel;

/**
 * Sets an optional log handler
 *
 * @param handler A close that takes `logLevel` and `message` to be logged.
 *
 * @discussion
 * By default Module uses `NSLog` for the logging purposes. If for some reasons it does not work for you, feel free to use `logHandler` to intercept log messages and direct them as required.
 */
- (void)logHandler:(nullable SNSLogHandler)handler;

#pragma mark - Settings

/**
 * Custom settings
 *
 * @discussion Reserved for the future needs.
 */
@property (nonatomic, nullable) NSDictionary *settings;

#pragma mark - Aliases

/// Alias for `tokenExpirationHandler:` method
- (void)setTokenExpirationHandler:(nullable SNSTokenExpirationHandler)handler;
/// Alias for `completionHandler:` method
- (void)setCompletionHandler:(nullable SNSLiveness3DCompletionHandler)handler;
/// Alias for `resultHandler:` method
- (void)setResultHandler:(nullable SNSLiveness3DResultHandler)handler;
/// Alias for `logHandler:` method
- (void)setLogHandler:(nullable SNSLogHandler)handler;

@end
