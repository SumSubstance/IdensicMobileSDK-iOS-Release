//
//  IdensicMobileSDK.h
//  IdensicMobileSDK
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK.
FOUNDATION_EXPORT double IdensicMobileSDKVersionNumber;

//! Project version string for IdensicMobileSDK.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDKVersionString[];

#import "SNSMobileSDK.h"
#import "SNSSupportItem.h"
#import "SNSTheme.h"
#import "SNSLiveness3DTheme.h"
#import "SNSLiveness3DThemeProtocol.h"
