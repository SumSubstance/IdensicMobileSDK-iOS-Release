//
//  IdensicMobileSDK_EID.h
//  IdensicMobileSDK_EID
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK_EID.
FOUNDATION_EXPORT double IdensicMobileSDK_EIDVersionNumber;

//! Project version string for IdensicMobileSDK_EID.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDK_EIDVersionString[];
