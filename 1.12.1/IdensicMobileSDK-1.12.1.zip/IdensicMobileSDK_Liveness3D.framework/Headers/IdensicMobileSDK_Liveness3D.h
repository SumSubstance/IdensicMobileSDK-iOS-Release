//
//  IdensicMobileSDK_Liveness3D.h
//  IdensicMobileSDK_Liveness3D
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK_Liveness3D.
FOUNDATION_EXPORT double IdensicMobileSDK_Liveness3DVersionNumber;

//! Project version string for IdensicMobileSDK_Liveness3D.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDK_Liveness3DVersionString[];

#import "SNSLiveness3D.h"
#import "SNSLiveness3DResult.h"
