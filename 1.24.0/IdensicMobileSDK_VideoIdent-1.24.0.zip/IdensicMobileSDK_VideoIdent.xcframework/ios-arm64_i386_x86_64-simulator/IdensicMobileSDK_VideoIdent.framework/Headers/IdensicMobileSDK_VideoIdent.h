//
//  IdensicMobileSDK_VideoIdent.h
//  IdensicMobileSDK_VideoIdent
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK_VideoIdent.
FOUNDATION_EXPORT double IdensicMobileSDK_VideoIdentVersionNumber;

//! Project version string for IdensicMobileSDK_VideoIdent.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDK_VideoIdentVersionString[];

