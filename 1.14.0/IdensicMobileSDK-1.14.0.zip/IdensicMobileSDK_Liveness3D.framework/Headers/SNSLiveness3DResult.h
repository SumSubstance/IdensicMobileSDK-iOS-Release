//
//  SNSLiveness3DResult.h
//  IdensicMobileSDK_Liveness3D
//
//  Copyright © 2019 Sum & Substance. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SNSLiveness3DResult : NSObject

/**
 * actionId to check the results against the server
 */
@property (nonatomic, readonly, nullable) NSString *applicantActionId;

/**
 * Overall result. Possible values are `GREEN`, `RED` or `ERROR`.
 */
@property (nonatomic, readonly, nullable) NSString *reviewAnswer;

/**
 * Retry suggestion, if applicable
 */
@property (nonatomic, readonly, nullable) NSString *retrySuggestion;

/**
 * List of reject labels, if applicable
 */
@property (nonatomic, readonly, nullable) NSArray<NSString *> *rejectLabels;

/**
 * Liveness check result. Possible values are `GREEN`, `RED` or `ERROR`.
 */
@property (nonatomic, readonly, nullable) NSString *livenessCheckAnswer;

/**
 * Face match check result. Possible values are `GREEN`, `RED` or `ERROR`.
 */
@property (nonatomic, readonly, nullable) NSString *faceMatchCheckAnswer;

/**
 * A flag allows liveness check to be considered successful despite of the value of `livenessCheckAnswer`
 */
@property (nonatomic, readonly) BOOL allowContinuing;

@end
