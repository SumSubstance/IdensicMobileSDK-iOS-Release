//
//  Copyright © Sum & Substance. All rights reserved.
//

#ifndef SNSTrackButton_h
#define SNSTrackButton_h

typedef NS_CLOSED_ENUM(NSInteger, SNSTrackButton) {
    SNSTrackButton_SkipButton,
    SNSTrackButton_StartButton,
    SNSTrackButton_ContinueButton,
    SNSTrackButton_RotateButton,
    SNSTrackButton_AcceptButton,
    SNSTrackButton_RetakeButton,
    SNSTrackButton_RetryButton,
    SNSTrackButton_GoBackButton,
    SNSTrackButton_ActionButton,
    SNSTrackButton_CloseButton,
};

#endif /* SNSTrackButton_h */
