//
//  IdensicMobileSDK_Fisherman.h
//  IdensicMobileSDK_Fisherman
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK_Fisherman.
FOUNDATION_EXPORT double IdensicMobileSDK_FishermanVersionNumber;

//! Project version string for IdensicMobileSDK_Fisherman.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDK_FishermanVersionString[];
